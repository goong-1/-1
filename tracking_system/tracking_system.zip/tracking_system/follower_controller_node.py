import math

import rclpy
from rclpy.node import Node

from std_msgs.msg import String

import tf2_ros
from tf2_ros import TransformException
from std_msgs.msg import String, Bool

class FollowerControllerNode(Node):
    def __init__(self):
        super().__init__('follower_controller_node')

        self.declare_parameters(
            namespace='',
            parameters=[
                ('robot0_frame', 'robot0/base_link'),
                ('robot1_frame', 'robot1/base_link'),
                ('map_frame', 'map'),

                # path queue / jump
                ('min_save_dist', 0.05),          # 5cm
                ('jump_threshold', 0.80),         # 80cm
                ('jump_threshold_count', 10),
                ('target_reach_dist', 0.10),      # 10cm
                ('stop_threshold', 0.45),         # 45cm

                # speed
                ('base_speed_pwm', 90),
                ('max_speed_pwm', 120),
                ('speed_gain', 150.0),            # m 기준이라 크게 사용
                ('min_drive_pwm', 90),
                ('pwm_limit', 140),

                # steering
                ('steer_gain', 0.9),
                ('max_steer_pwm', 100),
                ('angle_deadzone', 3.0),

                # safety
                ('safety_gap', 0.30),
            ]
        )

        
        self.robot0_frame = self.get_parameter('robot0_frame').value
        self.robot1_frame = self.get_parameter('robot1_frame').value
        self.map_frame = self.get_parameter('map_frame').value

        self.min_save_dist = float(self.get_parameter('min_save_dist').value)
        self.jump_threshold = float(self.get_parameter('jump_threshold').value)
        self.jump_threshold_count = int(self.get_parameter('jump_threshold_count').value)
        self.target_reach_dist = float(self.get_parameter('target_reach_dist').value)
        self.stop_threshold = float(self.get_parameter('stop_threshold').value)

        self.base_speed_pwm = int(self.get_parameter('base_speed_pwm').value)
        self.max_speed_pwm = int(self.get_parameter('max_speed_pwm').value)
        self.speed_gain = float(self.get_parameter('speed_gain').value)
        self.min_drive_pwm = int(self.get_parameter('min_drive_pwm').value)
        self.pwm_limit = int(self.get_parameter('pwm_limit').value)

        self.steer_gain = float(self.get_parameter('steer_gain').value)
        self.max_steer_pwm = int(self.get_parameter('max_steer_pwm').value)
        self.angle_deadzone = float(self.get_parameter('angle_deadzone').value)
        self.prev_angle_error = 0.0
        self.kd_gain = 0.2

        self.safety_gap = float(self.get_parameter('safety_gap').value)

        self.tf_buffer = tf2_ros.Buffer()
        self.tf_listener = tf2_ros.TransformListener(self.tf_buffer, self)

        self.pub = self.create_publisher(String, '/robot1/motor_cmd', 10)

        self.manual_override = False
      
        #잠깐 수동 조작이 있었던 경우, 바로 자동 추종으로 복귀하면 로봇이 갑자기 튀는 현상 방지 위해 약간의 홀드 타임 적용
        self.last_manual_override_time = self.get_clock().now()
        self.manual_hold_sec = 0.8
        
        self.sub_manual_override = self.create_subscription(
            Bool,
            '/robot1/manual_override',
            self.manual_override_callback,
            10
        )

        self.path_queue = []
        self.last_saved_robot0_pos = None
        self.was_stopped = False

        self.timer = self.create_timer(0.1, self.timer_callback)

    def manual_override_callback(self, msg):
        self.manual_override = msg.data
        # 수동 조작이 들어오면 바로 자동 추종으로 복귀하지 않고 약간의 홀드 타임 적용
        if msg.data:
            self.last_manual_override_time = self.get_clock().now()
            self.get_logger().warn('[MANUAL OVERRIDE] robot1 자동추종 일시정지')
        else:
            self.last_manual_override_time = self.get_clock().now()
            self.get_logger().info('[MANUAL OVERRIDE] robot1 자동추종 복귀 대기')

    def make_cmd(self, pwm_l, pwm_r):
        def sign(n):
            return f'+{n}' if n >= 0 else str(n)

        return f'a{sign(int(pwm_l))},d{sign(int(pwm_r))}'

    def publish_stop(self, reason='정지'):
        msg = String()
        msg.data = 'a+0,d+0'
        self.pub.publish(msg)

        if not self.was_stopped:
            self.get_logger().info(f'[STOP] {reason}')

        self.was_stopped = True

    def publish_cmd(self, pwm_l, pwm_r, desc='MOVE'):
        msg = String()
        msg.data = self.make_cmd(pwm_l, pwm_r)
        self.pub.publish(msg)
        self.was_stopped = False

        self.get_logger().info(
            f'[{desc}] cmd={msg.data}, queue={len(self.path_queue)}'
        )

    def yaw_from_quaternion(self, q):
        siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
        cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
        return math.atan2(siny_cosp, cosy_cosp)

    def get_pose_2d(self, target_frame):
        tf = self.tf_buffer.lookup_transform(
            self.map_frame,
            target_frame,
            rclpy.time.Time()
        )

        x = tf.transform.translation.x
        y = tf.transform.translation.y
        yaw = self.yaw_from_quaternion(tf.transform.rotation)

        return x, y, yaw

    def distance(self, p1, p2):
        return math.sqrt((p1[0] - p2[0]) ** 2 + (p1[1] - p2[1]) ** 2)

    def save_robot0_path_if_needed(self, robot0_pos):
        if self.last_saved_robot0_pos is None:
            self.path_queue.append(robot0_pos)
            self.last_saved_robot0_pos = robot0_pos
            return

        moved = self.distance(robot0_pos, self.last_saved_robot0_pos)

        if moved >= self.min_save_dist:
            self.path_queue.append(robot0_pos)
            self.last_saved_robot0_pos = robot0_pos

    def map_to_robot1_local(self, target_point, robot1_pose):
        tx, ty = target_point
        rx, ry, ryaw = robot1_pose

        dx = tx - rx
        dy = ty - ry

        # map 좌표를 robot1 로컬 좌표로 변환
        local_x = math.cos(-ryaw) * dx - math.sin(-ryaw) * dy
        local_y = math.sin(-ryaw) * dx + math.cos(-ryaw) * dy

        return local_x, local_y

    def apply_min_pwm(self, pwm):
        if pwm == 0:
            return 0

        if 0 < abs(pwm) < self.min_drive_pwm:
            return self.min_drive_pwm if pwm > 0 else -self.min_drive_pwm

        return pwm

    def calculate_control(self, target_point, robot1_pose):
        local_x, local_y = self.map_to_robot1_local(target_point, robot1_pose)

        dist = math.sqrt(local_x ** 2 + local_y ** 2)
        angle_error = math.degrees(math.atan2(local_y, local_x))

        if dist <= self.target_reach_dist:
            return dist, angle_error, 0, 0, 'TARGET_REACHED'

        # 목표가 뒤쪽이면 제자리 회전
        if local_x < 0:
            turn_pwm = self.min_drive_pwm

            if local_y > 0:
                return dist, angle_error, -turn_pwm, turn_pwm, 'REAR_TARGET_TURN_LEFT'
            else:
                return dist, angle_error, turn_pwm, -turn_pwm, 'REAR_TARGET_TURN_RIGHT'

        # 거리 기반 속도
        base_pwm = self.base_speed_pwm + int(dist * self.speed_gain)
        base_pwm = min(base_pwm, self.max_speed_pwm)

        # 각도 deadzone
        if abs(angle_error) < self.angle_deadzone:
            steer = 0
        else:
            #steer = int(angle_error * self.steer_gain)
            # --- 여기부터 교체 ---
            # 1. 미분항(D) 계산: (현재 오차 - 이전 오차) / 시간 주기(0.1초)
            d_error = (angle_error - self.prev_angle_error) / 0.1[cite: 1]
            
            # 2. PD 제어 적용: (P항) + (D항)
            steer = int((angle_error * self.steer_gain) + (d_error * self.kd_gain))[cite: 1]
            
            # 3. 다음 루프를 위해 현재 오차를 저장
            self.prev_angle_error = angle_error[cite: 1]
            # --- 여기까지 교체 ---

        steer = max(min(steer, self.max_steer_pwm), -self.max_steer_pwm)

        # differential drive
        pwm_l = base_pwm - steer
        pwm_r = base_pwm + steer

        pwm_l = max(min(pwm_l, self.pwm_limit), -self.pwm_limit)
        pwm_r = max(min(pwm_r, self.pwm_limit), -self.pwm_limit)

        pwm_l = self.apply_min_pwm(pwm_l)
        pwm_r = self.apply_min_pwm(pwm_r)

        return dist, angle_error, pwm_l, pwm_r, 'FOLLOW_PATH'

    def timer_callback(self):
        
        # 수동 조작이 있었던 경우, 바로 자동 추종으로 복귀하면 로봇이 갑자기 튀는 현상 방지 위해 약간의 홀드 타임 적용
        now = self.get_clock().now()
        elapsed = (now - self.last_manual_override_time).nanoseconds / 1e9

        if self.manual_override or elapsed < self.manual_hold_sec:
            return

        try:
            robot0_pose = self.get_pose_2d(self.robot0_frame)
            robot1_pose = self.get_pose_2d(self.robot1_frame)

        except TransformException as e:
            self.publish_stop('TF 없음')
            self.get_logger().warn(f'TF 조회 실패: {e}', throttle_duration_sec=2.0)
            return

        robot0_pos = (robot0_pose[0], robot0_pose[1])
        robot1_pos = (robot1_pose[0], robot1_pose[1])

        realtime_dist = self.distance(robot0_pos, robot1_pos)

        # 1. robot0 경로 저장
        self.save_robot0_path_if_needed(robot0_pos)

        # 2. Jump 로직
        if realtime_dist >= self.jump_threshold or len(self.path_queue) >= self.jump_threshold_count:
            reason = (
                f'{realtime_dist * 100:.1f}cm 초과'
                if realtime_dist >= self.jump_threshold
                else f'큐 {len(self.path_queue)}개 초과'
            )

            self.path_queue.clear()
            self.path_queue.append(robot0_pos)

            self.get_logger().warn(
                f'[JUMP] {reason}! 최신 위치로 점프'
            )

        # 3. Safety stop
        dynamic_stop_dist = self.stop_threshold

        if len(self.path_queue) >= 5:
            dynamic_stop_dist = self.stop_threshold * 0.9

        if realtime_dist <= dynamic_stop_dist:
            self.publish_stop(
                f'인접 대기 dist={realtime_dist * 100:.1f}cm'
            )
            return

        # 4. 경로 없으면 정지
        if not self.path_queue:
            self.publish_stop('path_queue 비어 있음')
            return

        # 5. 현재 목표점
        target_point = self.path_queue[0]

        dist, angle, pwm_l, pwm_r, desc = self.calculate_control(
            target_point,
            robot1_pose
        )

        # 6. 목표점 도달 시 큐에서 제거
        if desc == 'TARGET_REACHED':
            self.path_queue.pop(0)

            if not self.path_queue:
                self.publish_stop('경로점 도달, 다음 목표 없음')
                return

            target_point = self.path_queue[0]
            dist, angle, pwm_l, pwm_r, desc = self.calculate_control(
                target_point,
                robot1_pose
            )

        self.publish_cmd(pwm_l, pwm_r, desc)

        self.get_logger().info(
            f'[CTRL] dist_to_target={dist:.3f}m, '
            f'realtime_gap={realtime_dist:.3f}m, '
            f'angle={angle:.1f}°, '
            f'queue={len(self.path_queue)}, '
            f'pwm_l={pwm_l}, pwm_r={pwm_r}'
        )
    

def main(args=None):
    rclpy.init(args=args)
    node = FollowerControllerNode()

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.publish_stop('종료')
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()