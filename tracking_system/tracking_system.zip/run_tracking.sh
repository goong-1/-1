#!/bin/bash

set -e

echo "기존 tracking_system 컨테이너 정리 중..."
docker rm -f tracking_system 2>/dev/null || true

echo "tracking-system:v1 이미지 실행 중..."

docker run -it --rm \
  --name tracking_system \
  --device=/dev/video0:/dev/video0 \
  --device=/dev/video1:/dev/video1 \
  -p 5001:5001 \
  -p 10000:10000 \
  tracking-system:v1