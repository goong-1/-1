#!/bin/bash

INTERVAL=2
DURATION=60
OUTPUT="resource_monitor_$(date +%Y%m%d_%H%M%S).csv"

PATTERN="aruco_tf_node|dashboard_node|robot_driver_node|follower_controller_node|follow_target_tf_node"

echo "timestamp,pid,node,cpu_percent,mem_percent,rss_kb,rss_mb" > "$OUTPUT"

echo "[INFO] Monitoring started"
echo "[INFO] interval=${INTERVAL}s, duration=${DURATION}s"
echo "[INFO] output=$OUTPUT"

END_TIME=$((SECONDS + DURATION))

while [ $SECONDS -lt $END_TIME ]; do
    TIMESTAMP=$(date "+%Y-%m-%d %H:%M:%S")

    PIDS=$(pgrep -f "$PATTERN")

    for PID in $PIDS; do
        CMD=$(tr '\0' ' ' < /proc/$PID/cmdline 2>/dev/null)

        if echo "$CMD" | grep -q "ros2 run"; then
            continue
        fi

        NODE=$(echo "$CMD" | grep -oE "aruco_tf_node|dashboard_node|robot_driver_node|follower_controller_node|follow_target_tf_node" | head -n 1)

        if [ -z "$NODE" ]; then
            continue
        fi

        DATA=$(ps -p "$PID" -o %cpu,%mem,rss --no-headers 2>/dev/null)

        if [ -n "$DATA" ]; then
            CPU=$(echo "$DATA" | awk '{print $1}')
            MEM=$(echo "$DATA" | awk '{print $2}')
            RSS=$(echo "$DATA" | awk '{print $3}')
            RSS_MB=$(awk "BEGIN {printf \"%.1f\", $RSS/1024}")

            echo "$TIMESTAMP,$PID,$NODE,$CPU,$MEM,$RSS,$RSS_MB" >> "$OUTPUT"
        fi
    done

    sleep "$INTERVAL"
done

echo "[INFO] Monitoring finished"
echo "[INFO] saved to $OUTPUT"