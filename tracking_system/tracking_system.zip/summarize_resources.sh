#!/bin/bash

FILE=$1

if [ -z "$FILE" ]; then
    echo "Usage: ./summarize_resources.sh resource_monitor_xxx.csv"
    exit 1
fi

echo "[INFO] Summary for $FILE"
echo

awk -F',' '
NR > 1 {
    node=$3
    cpu[node]+=$4
    mem[node]+=$5
    rss[node]+=$6
    count[node]++
}
END {
    total_cpu=0
    total_rss=0

    printf "%-30s %12s %12s %12s\n", "NODE", "AVG_CPU(%)", "AVG_RSS(KB)", "AVG_RSS(MB)"
    printf "%-30s %12s %12s %12s\n", "----", "----------", "-----------", "-----------"

    for (n in count) {
        avg_cpu=cpu[n]/count[n]
        avg_rss=rss[n]/count[n]
        avg_rss_mb=avg_rss/1024

        total_cpu += avg_cpu
        total_rss += avg_rss

        printf "%-30s %12.2f %12.0f %12.1f\n", n, avg_cpu, avg_rss, avg_rss_mb
    }

    printf "\n%-30s %12.2f %12.0f %12.1f\n", "TOTAL", total_cpu, total_rss, total_rss/1024
}
' "$FILE"
