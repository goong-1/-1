// [1. 핀 설정] 
// 🌟 만약 'W'를 눌렀는데 뒤로 간다면, A와 B의 핀 번호를 서로 바꾸세요!
const int leftMotorA = 10;  // 기존 10 -> 11로 수정 (방향 반전 대응)
const int leftMotorB = 11;  // 기존 11 -> 10으로 수정
const int rightMotorA = 5;  // 기존 5 -> 6으로 수정
const int rightMotorB = 6;  // 기존 6 -> 5으로 수정

// 엔코더 핀 (2, 3번은 우노의 인터럽트 전용 핀입니다)
const int leftEncoderPin = 2;
const int rightEncoderPin = 3;

// [2. 변수 설정]
volatile long leftTicks = 0;
volatile long rightTicks = 0;

unsigned long lastSendTime = 0;
const unsigned long sendInterval = 50; 

void setup() {
  // 🌟 ESP32와 통신하는 속도 (ESP32의 Serial2.begin(9600...)과 일치해야 함)
  Serial.begin(9600);
  
  pinMode(leftMotorA, OUTPUT); pinMode(leftMotorB, OUTPUT);
  pinMode(rightMotorA, OUTPUT); pinMode(rightMotorB, OUTPUT);

  pinMode(leftEncoderPin, INPUT_PULLUP);
  pinMode(rightEncoderPin, INPUT_PULLUP);

  attachInterrupt(digitalPinToInterrupt(leftEncoderPin), countLeft, CHANGE);
  attachInterrupt(digitalPinToInterrupt(rightEncoderPin), countRight, CHANGE);
}

void loop() {
  // --- [수신] ESP32 -> 아두이노 (모터 제어) ---
  if (Serial.available() > 0) {
    String data = Serial.readStringUntil('\n'); // 🌟 줄바꿈(\n)이 나올 때까지 읽음
    
    if (data.startsWith("M:")) { // 모터 명령 헤더 확인
      int commaIdx = data.indexOf(',');
      if (commaIdx > 0) {
        // "M:75,150" 형태의 문자열을 잘라서 숫자로 변환
        int leftSpeed = data.substring(2, commaIdx).toInt();
        int rightSpeed = data.substring(commaIdx + 1).toInt();
        
        // 🌟 실제 모터 구동 함수 호출 (조합 키에 의한 미세 속도 반영)
        driveMotors(leftSpeed, rightSpeed);
      }
    }
  }

  // --- [송신] 아두이노 -> ESP32 (엔코더 피드백) ---
  if (millis() - lastSendTime >= sendInterval) {
    lastSendTime = millis();
    
    // "E:좌측틱,우측틱" 형태로 PC/ESP32에 보고
    Serial.print("E:");
    Serial.print(leftTicks);
    Serial.print(",");
    Serial.println(rightTicks);
  }
}

// 모터 구동 핵심 함수 (부호에 따라 방향 결정)
void driveMotors(int left, int right) {
  // 좌측 모터 제어
  if (left >= 0) { // 양수(+)면 전진
    analogWrite(leftMotorA, left); 
    analogWrite(leftMotorB, 0);
  } else { // 음수(-)면 후진
    analogWrite(leftMotorA, 0); 
    analogWrite(leftMotorB, -left); // 음수를 양수로 바꿔서 출력
  }
  
  // 우측 모터 제어
  if (right >= 0) {
    analogWrite(rightMotorA, right); 
    analogWrite(rightMotorB, 0);
  } else {
    analogWrite(rightMotorA, 0); 
    analogWrite(rightMotorB, -right);
  }
}

// 인터럽트 서비스 루틴 (회전 수 카운트)
void countLeft() { leftTicks++; }
void countRight() { rightTicks++; }