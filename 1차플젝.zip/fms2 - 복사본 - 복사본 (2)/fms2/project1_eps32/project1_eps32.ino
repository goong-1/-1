#include <WiFi.h>
#include <WebServer.h>

// 💡 본인의 Wi-Fi 정보로 수정하세요!
const char* ssid = "asia-edu_2G";
const char* password = "12345678";

WebServer server(80);

// 전역 속도 변수 (기본값 150)
int currentSpeed = 150;

// ================= [웹 대시보드 HTML/JS/CSS] =================
const char index_html[] PROGMEM = R"rawliteral(
<!DOCTYPE html>
<html lang="ko">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>로봇 관제 대시보드 (ESP32 Standalone)</title>
  <style>
    body { font-family: 'Segoe UI', sans-serif; background-color: #1e1e1e; color: #fff; text-align: center; margin: 0; padding: 20px; }
    .card { background: #2c2c2c; border-radius: 10px; padding: 20px; max-width: 400px; margin: 10px auto; }
    .btn { background-color: #3a3a3a; color: white; border: none; padding: 15px; font-size: 18px; border-radius: 10px; cursor: pointer; margin: 5px; user-select: none; }
    .btn:active { background-color: #4CAF50; }
    .speed-val { font-size: 32px; color: #4CAF50; font-weight: bold; margin: 10px 0; }
    .dpad { display: grid; grid-template-columns: repeat(3, 1fr); gap: 10px; max-width: 200px; margin: 0 auto; }
  </style>
</head>
<body>
  <h2>🚀 로봇 제어 시스템</h2>

  <div class="card">
    <h3>현재 출력 (Speed)</h3>
    <div class="speed-val" id="speedDisp">150</div>
    <button class="btn" onclick="changeSpeed(10)" style="width: 80px; background: #45a049;">가속 (+)</button>
    <button class="btn" onclick="changeSpeed(-10)" style="width: 80px; background: #e53935;">감속 (-)</button>
  </div>

  <div class="card">
    <h3>주행 제어 (WASD 조합 가능)</h3>
    <div class="dpad">
      <div></div>
      <button class="btn" id="btnW">W</button>
      <div></div>
      <button class="btn" id="btnA">A</button>
      <button class="btn" id="btnS">S</button>
      <button class="btn" id="btnD">D</button>
    </div>
    <button class="btn" style="width: 100%; background: #d32f2f; margin-top: 15px;" onclick="sendCmd('x')">긴급 정지 (X)</button>
  </div>

  <script>
    let keys = {};      // 현재 눌린 키 상태 저장
    let lastAction = ""; // 마지막으로 보낸 명령 저장 (중복 방지)

    function sendCmd(action) {
      fetch(`/action?go=${action}`);
      console.log("명령 전송: " + action);
    }

    function changeSpeed(delta) {
      let speed = parseInt(document.getElementById('speedDisp').innerText);
      speed = Math.min(255, Math.max(0, speed + delta));
      document.getElementById('speedDisp').innerText = speed;
      fetch(`/setSpeed?val=${speed}`);
    }

    // 🌟 [핵심] 눌린 키 조합을 분석하여 적절한 명령을 결정하는 함수
    function updateMovement() {
      let action = "x"; // 기본값은 정지

      // 조합 키 우선순위 (8방향 제어)
      if (keys['w'] && keys['a']) action = "wa";
      else if (keys['w'] && keys['d']) action = "wd";
      else if (keys['s'] && keys['a']) action = "sa";
      else if (keys['s'] && keys['d']) action = "sd";
      else if (keys['w']) action = "w";
      else if (keys['s']) action = "s";
      else if (keys['a']) action = "a";
      else if (keys['d']) action = "d";

      // 🌟 [중복 방지] 명령이 바뀔 때만 딱 한 번 전송
      if (action !== lastAction) {
        sendCmd(action);
        lastAction = action;
        
        // 버튼 UI 강조
        ['w', 'a', 's', 'd'].forEach(k => {
          const btn = document.getElementById('btn' + k.toUpperCase());
          if (keys[k]) btn.style.backgroundColor = '#4CAF50';
          else btn.style.backgroundColor = '#3a3a3a';
        });
      }
    }

    document.addEventListener('keydown', (e) => {
      const key = e.key.toLowerCase();
      if(['w', 'a', 's', 'd'].includes(key)) {
        keys[key] = true;
        updateMovement();
      }
      if(e.key === 'PageUp') changeSpeed(10);
      if(e.key === 'PageDown') changeSpeed(-10);
    });

    document.addEventListener('keyup', (e) => {
      const key = e.key.toLowerCase();
      if(['w', 'a', 's', 'd'].includes(key)) {
        keys[key] = false;
        updateMovement();
      }
    });
  </script>
</body>
</html>
)rawliteral";
// =============================================================

void setup() {
  Serial.begin(115200);
  Serial2.begin(9600, SERIAL_8N1, 16, 17);

  WiFi.begin(ssid, password);
  Serial.print("Wi-Fi 연결 중...");
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\n연결 성공!");
  Serial.print("IP 주소: "); Serial.println(WiFi.localIP());

  server.on("/", []() { server.send(200, "text/html", index_html); });

  server.on("/setSpeed", []() {
    if (server.hasArg("val")) currentSpeed = server.arg("val").toInt();
    server.send(200, "text/plain", "OK");
  });

  server.on("/action", []() {
    if (server.hasArg("go")) {
      String go = server.arg("go");
      String cmd = "M:0,0\n";
      int half = currentSpeed / 2;

      // 🌟 주행 명령 맵핑 (제자리 회전 vs 곡선 회전)
      if(go == "w")       cmd = "M:" + String(currentSpeed) + "," + String(currentSpeed) + "\n";
      else if(go == "s")  cmd = "M:-" + String(currentSpeed) + ",-" + String(currentSpeed) + "\n";
      
      // 단독 입력 시: 제자리 회전 (Spin Turn)
      else if(go == "a")  cmd = "M:-" + String(currentSpeed) + "," + String(currentSpeed) + "\n";
      else if(go == "d")  cmd = "M:" + String(currentSpeed) + ",-" + String(currentSpeed) + "\n";

      // 조합 입력 시: 곡선 회전 (Curve Turn)
      else if(go == "wa") cmd = "M:" + String(half) + "," + String(currentSpeed) + "\n";
      else if(go == "wd") cmd = "M:" + String(currentSpeed) + "," + String(half) + "\n";
      else if(go == "sa") cmd = "M:-" + String(half) + ",-" + String(currentSpeed) + "\n";
      else if(go == "sd") cmd = "M:-" + String(currentSpeed) + ",-" + String(half) + "\n";
      
      else if(go == "x")  cmd = "M:0,0\n";

      Serial2.print(cmd); 
      Serial.print("명령 전송: "); Serial.print(cmd);
    }
    server.send(200, "text/plain", "OK");
  });

  server.begin();
}

void loop() { server.handleClient(); }